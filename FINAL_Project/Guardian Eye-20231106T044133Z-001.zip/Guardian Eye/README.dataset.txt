# Guardian Eye > 2023-10-30 2:18pm
https://universe.roboflow.com/guardian-eye/guardian-eye-xyexl

Provided by a Roboflow user
License: Public Domain

